export { default as AboutHero } from './AboutHero';
export { default as AboutWhat } from './AboutWhat';
export { default as AboutTeam } from './AboutTeam';
export { default as AboutVision } from './AboutVision';
export { default as AboutTestimonials } from './AboutTestimonials';
